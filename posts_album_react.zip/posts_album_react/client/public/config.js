configs = {
    apiUrl: 'http://localhost:3001/api/',
};
