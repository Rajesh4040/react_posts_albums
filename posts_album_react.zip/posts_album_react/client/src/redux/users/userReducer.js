import { GET_USERS_PENDING, GET_USERS_SUCCESS, GET_USERS_ERROR } from './userActions';


const initialState = {
    pending: false,
    users: [],
    error: null
}

export function usersReducer(state = initialState, action) {
    switch (action.type) {
        case GET_USERS_PENDING:
            return {
                ...state,
                pending: true
            }
        case GET_USERS_SUCCESS:
            return {
                ...state,
                pending: false,
                users: action.payload
            }
        case GET_USERS_ERROR:
            return {
                ...state,
                pending: false,
                error: action.error
            }
        default:
            return state;
    }
}

export const getUsers = state => state.users;
export const getUsersPending = state => state.pending;
export const getUsersError = state => state.error;