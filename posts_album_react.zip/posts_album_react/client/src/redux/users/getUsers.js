
import { getusersPending, getusersSuccess, getusersError } from './userActions';

function getUsersAction() {
    return dispatch => {
        dispatch(getpostsPending());
        fetch('http://jsonplaceholder.typicode.com/users')
            .then(res => res.json())
            .then(res => {
                if (res.error) {
                    throw (res.error);
                }
                dispatch(getpostsSuccess(res.users));
                return res.users;
            })
            .catch(error => {
                dispatch(getpostsError(error));
            })
    }
}

export default getUsersAction;