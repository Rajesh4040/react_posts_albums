import { GET_POSTS_PENDING, GET_POSTS_SUCCESS, GET_POSTS_ERROR } from './postActions';


const initialState = {
    pending: false,
    posts: [],
    error: null
}

export function postsReducer(state = initialState, action) {
    switch (action.type) {
        case GET_POSTS_PENDING:
            return {
                ...state,
                pending: true
            }
        case GET_POSTS_SUCCESS:
            return {
                ...state,
                pending: false,
                posts: action.payload
            }
        case GET_POSTS_ERROR:
            return {
                ...state,
                pending: false,
                error: action.error
            }
        default:
            return state;
    }
}

export const getPosts = state => state.posts;
export const getPostsPending = state => state.pending;
export const getPostsError = state => state.error;