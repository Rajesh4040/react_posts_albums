
export const GET_POSTS_PENDING = 'GET_POSTS_PENDING';
export const GET_POSTS_SUCCESS = 'GET_POSTS_SUCCESS';
export const GET_POSTS_ERROR = 'GET_POSTS_ERROR';

export function getpostsPending() {
    return {
        type: GET_POSTS_PENDING
    }
}

export function getpostsSuccess(posts) {
    return {
        type: GET_POSTS_SUCCESS,
        posts: posts
    }
}

export function getpostsError(error) {
    return {
        type: GET_POSTS_ERROR,
        error: error
    }
}
