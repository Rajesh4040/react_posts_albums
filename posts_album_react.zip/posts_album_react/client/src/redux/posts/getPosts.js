
import { getpostsPending, getpostsSuccess, getpostsError } from './postActions';

function getPostsAction() {
    return dispatch => {
        dispatch(getpostsPending());
        fetch('http://jsonplaceholder.typicode.com/posts')
            .then(res => res.json())
            .then(res => {
                if (res.error) {
                    throw (res.error);
                }
                dispatch(getpostsSuccess(res.posts));
                return res.posts;
            })
            .catch(error => {
                dispatch(getpostsError(error));
            })
    }
}

export default getPostsAction;