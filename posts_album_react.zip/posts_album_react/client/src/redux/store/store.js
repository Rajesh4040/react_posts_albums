import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import { postsReducer } from '../posts/postReducer'
import { usersReducer } from '../users/userReducer'

const middlewares = [thunk];
const rootreducer = combineReducers({ posts: postsReducer, users: usersReducer });

const store = createStore(rootreducer, applyMiddleware(...middlewares));
export default store;
