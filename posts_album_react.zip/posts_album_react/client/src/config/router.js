/* eslint-disable import/first */
// Router set up
const React = require('react');
import { Route, BrowserRouter as Router } from 'react-router-dom';

// Components
import App from '../App';
import AlbumsComponent from '../components/albums';
import MainPage from '../components/MainPage';
import PostDetail from '../components/PostDetail';
import AddPostComponent from '../components/addpost';
const routing = (
    <Router>
        <div>
            <Route exact path='/' component={App} />
            <Route exact path='/posts' component={MainPage} />
            <Route exact path='/addpost' component={AddPostComponent} />
            <Route path="/albums" component={AlbumsComponent} />
            <Route path='/post/:postId' component={PostDetail} />

        </div>
    </Router>
);
export default routing;
