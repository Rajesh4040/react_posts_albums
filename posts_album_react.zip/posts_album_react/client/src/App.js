import React, { Component } from 'react';
import './App.css';
import { Container, Navbar, Nav, NavDropdown } from 'react-bootstrap';
import AlbumsComponent from './components/albums.js';
import MainPage from './components/MainPage.js';
import axios from 'axios';
import store from './redux/store/store.js'
import { Provider } from 'react-redux'

const UserContext = React.createContext();
const UserProvider = UserContext.Provider;
export const UserConsumer = UserContext.Consumer;


class App extends Component {
    constructor(props) {
        super(props);
        this.state = { users: [], selectedUser: -1, mainPageselect: false, getcount: null, usercount: "" };
        this.selectUser = this.selectUser.bind(this);
        this.clickMainpage = this.clickMainpage.bind(this);

    }
    getpostcount = (test) => {
        console.log('recevied child', test)
        this.setState({ getcount: test });


    }
    render() {

        const { users, mainPageselect } = this.state;

        let show;
        if (mainPageselect) {

            show = <MainPage data={
                {
                    getcount: this.getcount,
                    getpostcount: this.getpostcount.bind(this)

                }


            } lazy />;

        }
        return (
            <Provider store={store}>
                <UserProvider value="dark">
                    < Container >
                        <Navbar bg="light" expand="lg">
                            <Navbar.Brand href="#posts">
                                POSTS & ALBUMS
                    </Navbar.Brand>
                            <Navbar.Toggle aria-controls="basic-navbar-nav" />
                            <Navbar.Collapse id="basic-navbar-nav">
                                <Nav className="mr-auto">
                                    <Nav.Link onClick={this.clickMainpage.bind(this)}>Posts ({this.state.getcount}) </Nav.Link>
                                    {

                                        <NavDropdown title={"Users(" + this.state.usercount + ")"}
                                            id="basic-nav-dropdown">
                                            {users.map(user => (
                                                <NavDropdown.Item
                                                    key={user.id}
                                                    onClick={this.selectUser.bind(
                                                        this,
                                                        user.id,
                                                    )}
                                                >
                                                    {user.name}
                                                </NavDropdown.Item>
                                            ))}
                                        </NavDropdown>

                                    }
                                </Nav>
                            </Navbar.Collapse>
                        </Navbar>
                        {show}

                        <AlbumsComponent lazy userId={this.state.selectedUser} />
                    </Container >

                </UserProvider>
            </Provider>
        );
    }

    componentDidMount() {
        this.getUsers();
        this.loadPosts();
    }
    clickMainpage() {
        this.setState({ mainPageselect: true })
    }
    selectUser(index) {
        console.log('selected:', index);

        this.setState({ selectedUser: index, mainPageselect: false });

    }

    getUsers = () => {
        fetch(`${window.configs.apiUrl}users`)
            .then(data => data.json())
            .then(
                res => this.setState(
                    {
                        users: res,
                        usercount: res.length
                    }
                )
            );
    };

    loadPosts() {
        return axios.get('http://jsonplaceholder.typicode.com/posts')
            .then((response) => {
                return this.setState({
                    isDataLoading: false,
                    posts: response.data,
                    getcount: response.data.length
                })
            })
            .catch((error) => {

                throw error
            })
    }


}

export default App;
