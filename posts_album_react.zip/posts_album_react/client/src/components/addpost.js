import React from 'react';
//import axios from 'axios'

export default class AddPostComponent extends React.Component {
   constructor(props) {
      super(props);
      this.state = {
         title: '',
         body: ''
      }
      // this.handledata = this.handledata.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
   }

   handleSubmit(event) {

      const data = {
         userId: 1,
         id: 101,
         title: this.state.title,
         body: this.state.body,
      }
      event.preventDefault();
      //  const url = 'https://jsonplaceholder.typicode.com/posts'
      console.log('ddddd', data);
      fetch("https://jsonplaceholder.typicode.com/posts", {
         mode: 'no-cors',
         method: "POST",
         body: JSON.stringify(data)
      }).then(function (res) {
         console.log('res', res)
         if (res.ok) {
            console.log('success', res)
            alert("Perfect! ");
         } else if (res.status === 401) {
            alert("Oops! ");
         }
      }, function (e) {
         console.log('error', e)
         alert("Error submitting form!");
      });




   }
   handledata = (event) => {
      const target = event.target;
      const value = target.type === 'checkbox' ? target.checked : target.value;
      const name = target.name;

      this.setState({
         [name]: value
      });
   }


   render() {
      return (

         <div id="signup">
            <form onSubmit={this.handleSubmit}>
               <input type="text" value={this.state.title} name="title" onChange={this.handledata} placeholder="title" /><br />
               <input type="text" value={this.state.body} name="body" onChange={this.handledata} placeholder="body" /><br />
               <button type="Submit">Submit Post</button>
            </form>

         </div>

      )
   }
}